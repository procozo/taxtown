import { Component, OnInit } from '@angular/core';
import { Accordion } from 'primeng/accordion';
import { VoiceRecognitionService } from 'src/app/services/voice-recognition.service';
@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.scss'],
  providers: [VoiceRecognitionService, Accordion],
})
export class MemberComponent implements OnInit {
  isLoaded = false;
  isStartRecording = false;
  isHistory = false;
  ngOnInit() {
    try {
      setTimeout(() => {
        this.isLoaded = true;
      }, 2000);

      this.getMedia({ audio: true, video: false });

      this.voices = speechSynthesis.getVoices();
      this.selectedVoice = this.voices[0] || null;
      this.updateSayCommand();

      // The voices aren't immediately available (or so it seems). As such, if no
      // voices came back, let's assume they haven't loaded yet and we need to wait for
      // the "voiceschanged" event to fire before we can access them.
      if (!this.voices.length) {
        speechSynthesis.addEventListener('voiceschanged', () => {
          this.voices = speechSynthesis.getVoices();
          this.selectedVoice = this.voices[0] || null;
          this.updateSayCommand();
        });
      }
    } catch (error) {}
  }

  async getMedia(constraints: any) {
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia(constraints);

      console.log(stream);
      this.voiceservice.init();
    } catch (err) {
      document.write(err as any);
    }
  }
  public sayCommand!: string;
  public rates!: number[];
  public selectedRate!: number;
  public selectedVoice!: SpeechSynthesisVoice | null;
  public text!: string;
  public voices!: SpeechSynthesisVoice[];

  isAPICall = false;

  constructor(public voiceservice: VoiceRecognitionService) {}

  ngAfterViewInit() {
    try {
      //	build scene
      let loaded = 0;

      this.text = 'sure Vinayaka, I will take you to home screen';
      this.speak();

      const viewer = document.querySelector('.viewer');
      const loader = document.querySelector('h2 span');
      const images: any = [];
      for (let i = 1; i <= 8; ++i) {
        const img = new Image();
        img.src = `assets/360/${('' + i).slice(-3)}.svg`;
        img.onload = () =>
          ((loader as any).innerText = `${Math.round(
            (++loaded / 120) * 360
          )}˚360 degree`);
        images.push(img);
        (viewer as any).appendChild(img);
      }
      const threshold = 5;
      const total = images.length - 1;
      let frame = 0;
      // console.log(Impetus);

      images[frame].classList.add('active');

      //	cursor
      addEventListener(
        'mousedown',
        (e) => (document.body.style.cursor = 'grabbing')
      );
      addEventListener('mouseup', (e) => (document.body.style.cursor = 'grab'));

      // ROOT_PATH + '/data/asset/geo/Veins_Medical_Diagram_clip_art.svg',
      let base = +new Date(1968, 9, 3);
      let oneDay = 24 * 3600 * 1000;
      let date = [];
      let data = [Math.random() * 300];
      for (let i = 1; i < 20000; i++) {
        var now = new Date((base += oneDay));
        date.push(
          [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('/')
        );
        data.push(Math.round((Math.random() - 0.5) * 20 + data[i - 1]));
      }

      //  echarts.registerMap("organ_diagram", { svg: svg });
    } catch (error) {}
  }

  startService() {
    try {
      console.log('recording');
      this.voiceservice.start();
      this.isStartRecording = true;

      this.voiceservice.text = '';
    } catch (error) {}
  }

  stopService() {
    this.isStartRecording = false;
    this.voiceservice.stop();
    console.log(this.voiceservice.text);
    this.text = this.voiceservice.text;

    if (this.text.includes('go to home')) {
      this.text = this.voiceservice.text =
        'sure Vinayaka, I will take you to home screen';
      this.speak();
    } else {
      this.speak();
    }
  }

  // ---
  // PUBLIC METHODS.
  // ---

  // I demo the currently-selected voice.
  public demoSelectedVoice(): void {
    if (!this.selectedVoice) {
      console.warn('Expected a voice, but none was selected.');
      return;
    }

    var demoText = 'Best wishes and warmest regards.';

    this.stop();
    this.synthesizeSpeechFromText(
      this.selectedVoice,
      this.selectedRate,
      demoText
    );
  }

  // I get called once after the inputs have been bound for the first time.

  // I synthesize speech from the current text for the currently-selected voice.
  public speak(): void {
    if (!this.selectedVoice || !this.text) {
      return;
    }

    this.stop();
    this.synthesizeSpeechFromText(
      this.selectedVoice,
      this.selectedRate,
      this.text
    );
  }

  // I stop any current speech synthesis.
  public stop(): void {
    if (speechSynthesis.speaking) {
      speechSynthesis.cancel();
    }
  }

  // I update the "say" command that can be used to generate the a sound file from the
  // current speech synthesis configuration.
  public updateSayCommand(): void {
    if (!this.selectedVoice || !this.text) {
      return;
    }

    // With the say command, the rate is the number of words-per-minute. As such, we
    // have to finagle the SpeechSynthesis rate into something roughly equivalent for
    // the terminal-based invocation.
    var sanitizedRate = Math.floor(200 * this.selectedRate);
    var sanitizedText = this.text
      .replace(/[\r\n]/g, ' ')
      .replace(/(["'\\\\/])/g, '\\$1');
    this.sayCommand = `say --voice ${this.selectedVoice.name} --rate ${sanitizedRate} --output-file=demo.aiff "${sanitizedText}"`;
  }

  // ---
  // PRIVATE METHODS.
  // ---

  // I perform the low-level speech synthesis for the given voice, rate, and text.
  private synthesizeSpeechFromText(
    voice: SpeechSynthesisVoice,
    rate: number,
    text: string
  ): void {
    console.log(voice);
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = this.selectedVoice;
    utterance.rate = rate;

    speechSynthesis.speak(utterance);
  }
}
