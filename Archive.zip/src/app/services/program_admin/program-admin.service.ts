import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { number } from "echarts";
import { Subject } from "rxjs";
import { Constant } from "src/app/constant/constant";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root",
})
export class ProgramAdminService {
  programData$: Subject<any> = new Subject();

  constructor(private http: HttpClient) {}

  /**
   * cm program metadata api
   */
  /**
   *
   * @returns
   */
  getProgramConfig() {
    return new Promise((resolve, reject) => {
      this.http
        .get(
          environment.ENV_URL +
            Constant.constats.cmStratificationEndPoints.CM_CONFIG
        )
        .subscribe((res: unknown) => {
          if ((res as { status_code: number | String })?.status_code === 200) {
            resolve(res);
          }
          resolve(res);
          reject(false);
        });
    }).catch((err) => console.error(err));
  }

  /**
   * program search api call
   */
  /**
   *
   * @param data
   * @returns
   */
  getPrograms(data: unknown) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          environment.ENV_URL +
            Constant.constats.cmStratificationEndPoints.CM_PROGRAM_DETAILS,
          data
        )
        .subscribe((res: any) => {
          if (res?.status_code === 200) {
            resolve(res);
          }
          resolve(false);
          reject(false);
        });
    }).catch((err) => console.error(err));
  }

  /**
   *
   * @param program_id
   * @returns
   */
  deleteProgram(program_id: number) {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        program_id: program_id,
      },
    };
    return new Promise((resolve, reject) => {
      this.http
        .delete(
          `${environment.ENV_URL}${Constant.constats.cmStratificationEndPoints.CM_PROGRAM}`+ "/" + program_id,
        
        )
        .subscribe((res: any) => {
          if (res?.status_code === 200) {
            resolve(res);
          }
          resolve(res);
          reject(false);
        });
    }).catch((err) => console.error(err));
  }
  /**
   *  program create
   */
  /**
   *
   * @param payload
   * @returns
   */
  programCreate(payload: {}) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          environment.ENV_URL +
            Constant.constats.cmStratificationEndPoints.CM_PROGRAM,
          payload
        )
        .subscribe((res: any) => {
          console.log("api response", res);

          if (res?.status_code === 200 || res?.status_code === 201) {
            resolve(res);
          }
          resolve(false);
          reject(false);
        });
    }).catch((err) => console.error(err));
  }

  /**
   *
   * @param id
   * @returns
   */
  viewPogram(id: number) {
    return new Promise((resolve, reject) => {
      this.http
        .get(
          environment.ENV_URL +
            Constant.constats.cmStratificationEndPoints.VIEW_PROGRAM +
            "?program_id=" +
            id
        )
        .subscribe((res: any) => {
          console.log("api response", res);

          if (res?.status_code === 200) {
            resolve(res);
          }
          resolve(res);
          reject(false);
        });
    }).catch((err) => console.error(err));
  }
}
