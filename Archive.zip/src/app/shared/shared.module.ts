import { TooltipModule } from 'primeng/tooltip';
import { DropdownModule } from 'primeng/dropdown';
import { BadgeModule } from 'primeng/badge';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SidebarModule } from 'primeng/sidebar';
import { NgModule } from '@angular/core';
import { AccordionModule } from 'primeng/accordion';
import { ButtonModule } from 'primeng/button';
import { ProgressBarModule } from 'primeng/progressbar';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MessagesModule } from 'primeng/messages';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';
import { MultiSelectModule } from 'primeng/multiselect';
import { SliderModule } from 'primeng/slider';
import { TableModule } from 'primeng/table';
import { HeaderComponent } from '../components/header/header.component';
@NgModule({
  declarations: [HeaderComponent],
  imports: [
    CommonModule,
    ButtonModule,
    SidebarModule,
    BadgeModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule,
    AccordionModule,
    TooltipModule,
    ProgressBarModule,
    HttpClientModule,
    MessagesModule,
    ToastModule,
    ProgressBarModule,
    TableModule,
    SliderModule,
    MultiSelectModule,
    ToastModule,
    ProgressBarModule,
  ],
  exports: [
    DropdownModule,
    BadgeModule,
    AccordionModule,
    TooltipModule,
    ProgressBarModule,
    HttpClientModule,
    MessagesModule,
    ToastModule,
    TableModule,
    SliderModule,
    MultiSelectModule,
    ToastModule,
    ProgressBarModule,
    HeaderComponent,
  ],
  providers: [MessageService, ConfirmationService],
  bootstrap: [],
})
export class SharedModule {}
