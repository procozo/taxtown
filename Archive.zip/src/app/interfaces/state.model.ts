
import { LDIGITALStore } from './store';

export interface AppState {
    readonly store: LDIGITALStore[];
}